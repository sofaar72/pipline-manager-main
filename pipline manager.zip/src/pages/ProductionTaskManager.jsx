import LayoutOne from "../layout/LayoutOne";
import MainContent from "../components/MainContent";
import FilesContent from "../components/FilesContent";
import {
  EpisodeManagerProvider,
  useEpisodeManagerContext,
} from "../assets/context/EpisodeManagerContext";
import { useEntities } from "../hooks/useEntities";
import { useEffect, useRef } from "react";
import { Outlet, useLocation, useNavigate, useParams } from "react-router-dom";
import NoFileContent from "../components/golbals/PlaceHolders.jsx/NoFileContent";
import PreviewPageContents from "../components/previewPage/PreviewPageContents";

const ProductionTaskManager = () => {
  const {
    entityResults,
    entityLoading,
    entityError,
    setSearch,
    currentPage,
    setCurrentPage,
    totalPages,
    fetchEntities,
    search,
    selectEntityType,
    selectedEntityType,
  } = useEntities({});
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const path = pathname.split("/");
  const { setDataType, dataType, setGlobalActiveEntity } =
    useEpisodeManagerContext();
  const location = useLocation();
  const fromPreviewRef = useRef(location.state?.fromPreview || false);
  const { id: urlId } = useParams();
  const { activePreviewPart } = useEpisodeManagerContext();

  useEffect(() => {
    fetchEntities();
  }, [search, currentPage, selectedEntityType]);

  useEffect(() => {
    setDataType("production");

    if (
      !urlId &&
      !fromPreviewRef.current &&
      entityResults &&
      entityResults.length > 0
    ) {
      navigate(`/task-manager/production/${entityResults[0]?.id}`);
    }
  }, [entityResults]);

  useEffect(() => {
    setDataType("production");
  }, [dataType]);

  // useEffect(() => {
  //   console.log(activePreviewPart);
  // }, [activePreviewPart]);

  return (
    <LayoutOne>
      {activePreviewPart ? (
        <PreviewPageContents />
      ) : (
        <div className="w-full h-full text-white flex gap-[30px] flex-col lg:flex-row">
          <MainContent
            dataType={dataType}
            entityResults={entityResults}
            entityLoading={entityLoading}
            entityError={entityError}
            setSearch={setSearch}
            currentPage={currentPage}
            setCurrentPage={setCurrentPage}
            selectEntityType={selectEntityType}
            totalPages={totalPages}
            selectedEntityType={selectedEntityType}
          />
          <Outlet />
          {/* <NoFileContent /> */}
          {/* {entityResults.length === 0 && <FilesContent />} */}
        </div>
      )}
    </LayoutOne>
  );
};

export default ProductionTaskManager;
