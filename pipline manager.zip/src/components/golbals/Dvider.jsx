import React from "react";

const Dvider = () => {
  return <div className="w-full h-[1px] line-grad"></div>;
};

export default Dvider;
