export const Files = [
  {
    id: 1,
    title: "File 1",
    size: "ver 1",
  },
  {
    id: 2,
    title: "Version 2",
    size: "ver 2",
  },
  ,
  {
    id: 3,
    title: "Version 3",
    size: "ver 3",
  },
  ,
  {
    id: 4,
    title: "Version 4",
    size: "ver 4",
  },
  ,
  {
    id: 5,
    title: "Version 5",
    size: "ver 5",
  },
  ,
  {
    id: 6,
    title: "Version 6",
    size: "ver 6",
    totalFiles: 3,
  },
];
