export const TypeTypes = ["bld", "prd"];
