export const assetChilds = ["child1", "child2", "child3"];
