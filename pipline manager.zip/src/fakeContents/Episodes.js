export const Episodes = [
  {
    id: "ep1",
    title: "Episode Begining",
    createdAt: "2021-01-01",
    updatedAt: "2021-01-01",
    type: "episode",
  },
  {
    id: "ep2",
    title: "Episode Begining",
    createdAt: "2021-01-01",
    updatedAt: "2021-01-01",
    type: "episode",
  },
  {
    id: "ep3",
    title: "Episode Begining",
    createdAt: "2021-01-01",
    updatedAt: "2021-01-01",
    type: "episode",
  },
];
