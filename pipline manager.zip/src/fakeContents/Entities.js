export const entities = ["Episodes", "Sequence", "Shot", "All"];
export const episodes = ["Episodes 1", "Episodes 2", "Episodes 3"];
