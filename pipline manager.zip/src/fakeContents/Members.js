export const Members = [
  {
    id: 1309,
    name: "Moghadam",
    email: "moghadam_h@arssin.com",
    avatar: "https://via.placeholder.com/150",
  },
  {
    id: 975,
    name: "Admin",
    email: "admin@admin.com",
    avatar: "https://via.placeholder.com/150",
  },
];
