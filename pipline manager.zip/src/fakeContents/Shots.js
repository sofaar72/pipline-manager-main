export const Shots = [
  {
    id: "seq1_shot1",
    title: "seq1_shot1",
    type: "shot",
    episode: "Episode 1",
  },
  {
    id: "seq1_shot2",
    title: "seq1_shot2",
    type: "shot",
    episode: "Episode 2",
  },
  {
    id: "seq1_shot3",
    title: "seq1_shot3",
    type: "shot",
    episode: "Episode 3",
  },
];
